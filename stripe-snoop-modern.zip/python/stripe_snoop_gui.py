#!/usr/bin/env python3
"""
Stripe Snoop Modern - GUI Application
=======================================
Modernized 64-bit Linux magstripe decoder with audio spectrum visualizer.

Based on original stripe-snoop by Acidus (acidus@yak.net)
Modernized for contemporary Linux systems with USB HID readers.

Dependencies:
    - Python 3.8+
    - numpy
    - matplotlib
    - tkinter (usually built-in)

Install deps: pip3 install numpy matplotlib

Usage:
    python3 stripe_snoop_gui.py
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib.animation import FuncAnimation
import threading
import queue
import time
import os
import sys
from datetime import datetime
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Callable
from enum import Enum, auto

# ============================================================================
# Magstripe Parser Core (Pure Python port of C++ logic)
# ============================================================================

class TrackID(Enum):
    Track1 = auto()
    Track2 = auto()
    Track3 = auto()

class CardType(Enum):
    Unknown = "Unknown"
    Visa = "Visa"
    MasterCard = "MasterCard"
    Amex = "American Express"
    Discover = "Discover"
    DinersClub = "Diners Club"
    JCB = "JCB"
    DriversLicense = "Driver's License"
    StudentID = "Student ID"
    GiftCard = "Gift Card"
    HotelKey = "Hotel Key Card"
    Banking = "Banking Card"
    Other = "Other"


@dataclass
class TrackData:
    track: TrackID
    raw: str = ""
    bitstream: str = ""
    valid: bool = False
    lrc_ok: bool = False
    error_msg: str = ""
    format_code: str = ""
    pan: str = ""
    name: str = ""
    expiry: str = ""
    service_code: str = ""
    discretionary: str = ""
    start_sentinel: str = ""
    end_sentinel: str = ""


@dataclass
class ParsedCard:
    tracks: List[TrackData] = field(default_factory=list)
    card_type: CardType = CardType.Unknown
    card_type_name: str = "Unknown"
    issuing_bank: str = ""
    country: str = ""
    state: str = ""

    def has_track(self, t: TrackID) -> bool:
        return any(tr.track == t for tr in self.tracks)

    def get_track(self, t: TrackID) -> Optional[TrackData]:
        for tr in self.tracks:
            if tr.track == t:
                return tr
        return None


class MagstripeParser:
    """Pure Python magstripe parser - modernized from original C code."""

    # Track 1: IATA 6-bit + odd parity (7 bits total)
    TRACK1_CHARS = (
        ' !"#$%&'()*+,-./0123456789:;<=>?'
        '@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_'
    )

    # Track 2/3: ABA 4-bit + odd parity (5 bits total)
    TRACK23_CHARS = '0123456789:;<=>?'

    # BIN to bank mapping (simplified)
    BIN_RANGES = [
        ((400000, 499999), "Visa Network"),
        ((510000, 559999), "MasterCard Network"),
        ((340000, 349999), "American Express"),
        ((370000, 379999), "American Express"),
        ((352800, 358999), "JCB"),
        ((601100, 601199), "Discover"),
        ((644000, 649999), "Discover"),
        ((650000, 659999), "Discover"),
        ((300000, 305999), "Diners Club"),
        ((309500, 309599), "Diners Club"),
        ((360000, 369999), "Diners Club"),
        ((380000, 399999), "Diners Club"),
        ((431300, 431399), "Maryland Bank NA (MBNA)"),
    ]

    def __init__(self, force_mode: bool = False):
        self.force_mode = force_mode

    def _popcount(self, n: int) -> int:
        return bin(n).count('1')

    def _parse_track1(self, bitstream: str) -> TrackData:
        td = TrackData(track=TrackID.Track1, bitstream=bitstream)

        if len(bitstream) < 7:
            td.error_msg = "Bitstream too short for Track 1"
            return td

        decoded = ""
        raw_bytes = []

        for i in range(0, len(bitstream) - 6, 7):
            byte = 0
            for j in range(7):
                if bitstream[i + j] == '1':
                    byte |= (1 << j)

            data_bits = byte & 0x3F
            parity_bit = (byte >> 6) & 0x01
            parity_count = self._popcount(data_bits)

            if data_bits < 64:
                decoded += self.TRACK1_CHARS[data_bits]
                raw_bytes.append(data_bits)

        td.raw = decoded

        # Parse Track 1 fields: %B PAN ^ NAME ^ YYMM SERVICE discretionary ? LRC
        if decoded and decoded[0] == '%':
            td.start_sentinel = "%"
            td.valid = True

            first_sep = decoded.find('^')
            if first_sep != -1:
                td.pan = decoded[1:first_sep]
                if td.pan and td.pan[0].isalpha():
                    td.format_code = td.pan[0]
                    td.pan = td.pan[1:]

                second_sep = decoded.find('^', first_sep + 1)
                if second_sep != -1:
                    td.name = decoded[first_sep + 1:second_sep]

                    end_sent = decoded.find('?', second_sep)
                    if end_sent != -1:
                        td.end_sentinel = "?"
                        remaining = decoded[second_sep + 1:end_sent]
                        if len(remaining) >= 4:
                            td.expiry = remaining[:4]
                            if len(remaining) >= 7:
                                td.service_code = remaining[4:7]
                                td.discretionary = remaining[7:]
        else:
            td.error_msg = "Missing start sentinel (%)"

        # LRC check
        if raw_bytes:
            lrc = 0
            for b in raw_bytes:
                lrc ^= b
            td.lrc_ok = (lrc == 0)

        return td

    def _parse_track2(self, bitstream: str) -> TrackData:
        td = TrackData(track=TrackID.Track2, bitstream=bitstream)

        if len(bitstream) < 5:
            td.error_msg = "Bitstream too short for Track 2"
            return td

        decoded = ""
        raw_bytes = []

        for i in range(0, len(bitstream) - 4, 5):
            byte = 0
            for j in range(5):
                if bitstream[i + j] == '1':
                    byte |= (1 << j)

            data_bits = byte & 0x0F
            if data_bits < 16:
                decoded += self.TRACK23_CHARS[data_bits]
                raw_bytes.append(data_bits)

        td.raw = decoded

        # Parse Track 2 fields: ; PAN = YYMM SERVICE discretionary ? LRC
        if decoded and decoded[0] == ';':
            td.start_sentinel = ";"
            td.valid = True

            sep = decoded.find('=')
            if sep != -1:
                td.pan = decoded[1:sep]

                end_sent = decoded.find('?', sep)
                if end_sent != -1:
                    td.end_sentinel = "?"
                    remaining = decoded[sep + 1:end_sent]
                    if len(remaining) >= 4:
                        td.expiry = remaining[:4]
                        if len(remaining) >= 7:
                            td.service_code = remaining[4:7]
                            td.discretionary = remaining[7:]
        else:
            td.error_msg = "Missing start sentinel (;)"

        if raw_bytes:
            lrc = 0
            for b in raw_bytes:
                lrc ^= b
            td.lrc_ok = (lrc == 0)

        return td

    def _parse_track3(self, bitstream: str) -> TrackData:
        td = TrackData(track=TrackID.Track3, bitstream=bitstream)

        if len(bitstream) < 5:
            td.error_msg = "Bitstream too short for Track 3"
            return td

        decoded = ""
        raw_bytes = []

        for i in range(0, len(bitstream) - 4, 5):
            byte = 0
            for j in range(5):
                if bitstream[i + j] == '1':
                    byte |= (1 << j)

            data_bits = byte & 0x0F
            if data_bits < 16:
                decoded += self.TRACK23_CHARS[data_bits]
                raw_bytes.append(data_bits)

        td.raw = decoded

        if decoded and decoded[0] == ';':
            td.start_sentinel = ";"
            td.valid = True

        if raw_bytes:
            lrc = 0
            for b in raw_bytes:
                lrc ^= b
            td.lrc_ok = (lrc == 0)

        return td

    def _analyze_card(self, card: ParsedCard) -> None:
        t1 = card.get_track(TrackID.Track1)
        t2 = card.get_track(TrackID.Track2)

        pan = ""
        if t2 and t2.pan:
            pan = t2.pan
        elif t1 and t1.pan:
            pan = t1.pan

        if not pan:
            return

        # Credit card detection by IIN
        if len(pan) >= 2:
            prefix1 = int(pan[0])
            prefix2 = int(pan[:2])
            prefix4 = int(pan[:4]) if len(pan) >= 4 else 0

            if prefix1 == 4:
                card.card_type = CardType.Visa
            elif 51 <= prefix2 <= 55:
                card.card_type = CardType.MasterCard
            elif prefix2 in (34, 37):
                card.card_type = CardType.Amex
            elif prefix4 == 6011 or prefix2 == 65:
                card.card_type = CardType.Discover
            elif prefix2 == 36:
                card.card_type = CardType.DinersClub
            elif prefix2 == 35:
                card.card_type = CardType.JCB

        # Driver's license detection
        if t1 and t1.raw:
            if t1.raw.startswith(("%A", "%B", "%C")):
                if "^DCS" in t1.raw or "^DCT" in t1.raw or "^DAQ" in t1.raw:
                    card.card_type = CardType.DriversLicense

        card.card_type_name = card.card_type.value
        card.issuing_bank = self._lookup_bank(pan)

    def _lookup_bank(self, pan: str) -> str:
        if len(pan) < 6:
            return "Unknown"
        try:
            bin_num = int(pan[:6])
            for (low, high), bank in self.BIN_RANGES:
                if low <= bin_num <= high:
                    return bank
        except ValueError:
            pass
        return "Unknown"

    def validate_luhn(self, pan: str) -> bool:
        """Validate PAN using Luhn algorithm."""
        total = 0
        reverse_digits = pan[::-1]
        for i, d in enumerate(reverse_digits):
            if not d.isdigit():
                continue
            n = int(d)
            if i % 2 == 1:
                n *= 2
                if n > 9:
                    n -= 9
            total += n
        return total % 10 == 0

    def parse_bitstream(self, bitstream: str, track_hint: TrackID = TrackID.Track2) -> ParsedCard:
        card = ParsedCard()

        # Clean input
        bitstream = ''.join(c for c in bitstream if c in '01')

        if not bitstream:
            return card

        # Try all tracks
        parsers = {
            TrackID.Track1: self._parse_track1,
            TrackID.Track2: self._parse_track2,
            TrackID.Track3: self._parse_track3,
        }

        for tid, parser in parsers.items():
            bpc = 7 if tid == TrackID.Track1 else 5
            if len(bitstream) >= bpc and len(bitstream) % bpc == 0:
                td = parser(bitstream)
                if td.valid or self.force_mode:
                    card.tracks.append(td)

        if not card.tracks and self.force_mode:
            td = parsers[track_hint](bitstream)
            card.tracks.append(td)

        self._analyze_card(card)
        return card

    def parse_keyboard_input(self, input_str: str) -> ParsedCard:
        """Parse input from USB HID keyboard-emulating magstripe reader."""
        card = ParsedCard()

        # Track 1: starts with '%'
        t1_start = input_str.find('%')
        if t1_start != -1:
            t1_end = input_str.find('?', t1_start)
            if t1_end != -1:
                t1_data = input_str[t1_start:t1_end + 1]
                bits = ""
                for c in t1_data:
                    if c in self.TRACK1_CHARS:
                        idx = self.TRACK1_CHARS.index(c)
                        parity = 1 if self._popcount(idx) % 2 == 0 else 0
                        full = (parity << 6) | idx
                        for b in range(7):
                            bits += '1' if (full >> b) & 1 else '0'

                td = self._parse_track1(bits)
                td.raw = t1_data
                td.valid = True
                card.tracks.append(td)

        # Track 2: starts with ';'
        t2_start = input_str.find(';')
        if t2_start != -1:
            t2_end = input_str.find('?', t2_start)
            if t2_end != -1:
                t2_data = input_str[t2_start:t2_end + 1]
                bits = ""
                for c in t2_data:
                    if c in self.TRACK23_CHARS:
                        idx = self.TRACK23_CHARS.index(c)
                        parity = 1 if self._popcount(idx) % 2 == 0 else 0
                        full = (parity << 4) | idx
                        for b in range(5):
                            bits += '1' if (full >> b) & 1 else '0'

                td = self._parse_track2(bits)
                td.raw = t2_data
                td.valid = True
                card.tracks.append(td)

        self._analyze_card(card)
        return card


# ============================================================================
# Audio Spectrum Visualizer
# ============================================================================

class SpectrumVisualizer:
    """
    Simulates an audio spectrum visualizer for magstripe F2F signals.

    Magstripe data uses F2F (Aiken Biphase) encoding:
    - '0': one flux reversal per bit cell (~1 kHz)
    - '1': two flux reversals per bit cell (~2 kHz)

    This visualizer generates a simulated signal and computes its FFT
    to show frequency content as the card is "swiped."
    """

    def __init__(self, sample_rate: float = 44100.0, bit_rate: float = 1000.0):
        self.sample_rate = sample_rate
        self.bit_rate = bit_rate
        self.bit_duration = 1.0 / bit_rate
        self.samples_per_bit = int(sample_rate * self.bit_duration)
        self.waveform: np.ndarray = np.array([])
        self.spectrum: np.ndarray = np.array([])
        self.freqs: np.ndarray = np.array([])
        self.current_pos = 0
        self.window_size = 2048
        self.bitstream = ""

    def load_bitstream(self, bitstream: str) -> None:
        """Generate waveform from bitstream."""
        self.bitstream = ''.join(c for c in bitstream if c in '01')
        if not self.bitstream:
            self.waveform = np.array([])
            return

        total_samples = len(self.bitstream) * self.samples_per_bit
        waveform = np.zeros(total_samples)

        for i, bit in enumerate(self.bitstream):
            start = i * self.samples_per_bit
            end = start + self.samples_per_bit
            t = np.arange(start, end) / self.sample_rate

            if bit == '1':
                # Two flux reversals per bit cell (~2x frequency)
                freq = self.bit_rate * 2.0
                signal = np.sign(np.sin(2 * np.pi * freq * t))
            else:
                # One flux reversal per bit cell
                freq = self.bit_rate
                signal = np.sign(np.sin(2 * np.pi * freq * t))

            # Add realistic noise
            noise = 0.02 * np.random.randn(len(t))
            waveform[start:end] = signal * 0.8 + noise

        self.waveform = waveform
        self.current_pos = 0

        # Pre-compute full spectrum
        if len(self.waveform) > self.window_size:
            self.freqs = np.fft.rfftfreq(self.window_size, 1.0 / self.sample_rate)

    def get_frame(self, advance: bool = True) -> tuple:
        """Get current spectrum frame. Returns (freqs, magnitudes, progress)."""
        if len(self.waveform) == 0:
            return np.array([]), np.array([]), 0.0

        end = min(self.current_pos + self.window_size, len(self.waveform))
        if end - self.current_pos < 256:
            self.current_pos = 0
            end = min(self.window_size, len(self.waveform))

        window = self.waveform[self.current_pos:end]
        if len(window) < self.window_size:
            window = np.pad(window, (0, self.window_size - len(window)))

        # Apply Hann window
        hann = np.hanning(len(window))
        windowed = window * hann

        # FFT
        fft = np.fft.rfft(windowed)
        magnitudes = np.abs(fft)

        # Normalize
        if np.max(magnitudes) > 0:
            magnitudes = magnitudes / np.max(magnitudes)

        # Use log scale for better visualization
        magnitudes = 20 * np.log10(magnitudes + 1e-10)
        magnitudes = np.clip(magnitudes, -80, 0)
        magnitudes = (magnitudes + 80) / 80  # Normalize to 0-1

        progress = self.current_pos / len(self.waveform)

        if advance:
            self.current_pos += self.window_size // 4  # 75% overlap
            if self.current_pos >= len(self.waveform):
                self.current_pos = 0

        freqs = np.fft.rfftfreq(self.window_size, 1.0 / self.sample_rate)
        return freqs, magnitudes, progress

    def reset(self) -> None:
        self.current_pos = 0


# ============================================================================
# Main GUI Application
# ============================================================================

class StripeSnoopGUI:
    """Modern GUI for Stripe Snoop with spectrum visualizer."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Stripe Snoop Modern - 64-bit Linux Magstripe Decoder")
        self.root.geometry("1200x900")
        self.root.minsize(1000, 700)

        # Set dark theme
        self._setup_theme()

        self.parser = MagstripeParser(force_mode=False)
        self.visualizer = SpectrumVisualizer()
        self.current_card: Optional[ParsedCard] = None
        self.animation: Optional[FuncAnimation] = None
        self.is_animating = False

        self._build_ui()
        self._setup_spectrum()

        # Keyboard reader mode
        self.keyboard_buffer = ""
        self.collecting = False
        self.root.bind('<Key>', self._on_key_press)

        # Status
        self.status_var.set("Ready. Swipe a card or load a bitstream file.")

    def _setup_theme(self) -> None:
        """Configure dark theme colors."""
        self.bg_color = "#1a1a2e"
        self.fg_color = "#e0e0e0"
        self.accent_color = "#00d4ff"
        self.secondary_bg = "#16213e"
        self.success_color = "#00ff88"
        self.error_color = "#ff3366"
        self.warning_color = "#ffaa00"

        self.root.configure(bg=self.bg_color)

        style = ttk.Style()
        style.theme_use('clam')

        style.configure('.', background=self.bg_color, foreground=self.fg_color)
        style.configure('TFrame', background=self.bg_color)
        style.configure('TLabel', background=self.bg_color, foreground=self.fg_color, font=('Consolas', 10))
        style.configure('TButton', background=self.secondary_bg, foreground=self.fg_color,
                        font=('Consolas', 10, 'bold'), padding=8)
        style.configure('Accent.TButton', background=self.accent_color, foreground=self.bg_color,
                        font=('Consolas', 11, 'bold'), padding=10)
        style.configure('TCheckbutton', background=self.bg_color, foreground=self.fg_color)
        style.configure('TEntry', fieldbackground=self.secondary_bg, foreground=self.fg_color,
                        insertcolor=self.fg_color)
        style.configure('TLabelframe', background=self.bg_color, foreground=self.accent_color)
        style.configure('TLabelframe.Label', background=self.bg_color, foreground=self.accent_color,
                        font=('Consolas', 11, 'bold'))
        style.configure('Horizontal.TProgressbar', background=self.accent_color, troughcolor=self.secondary_bg)

    def _build_ui(self) -> None:
        """Build the main user interface."""
        # Main container
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Title
        title = tk.Label(main_frame, text="STRIPE SNOOP MODERN",
                         font=('Consolas', 24, 'bold'), fg=self.accent_color, bg=self.bg_color)
        title.pack(pady=(0, 5))

        subtitle = tk.Label(main_frame, text="64-bit Linux Magstripe Decoder with Audio Spectrum Visualizer",
                           font=('Consolas', 11), fg=self.fg_color, bg=self.bg_color)
        subtitle.pack(pady=(0, 15))

        # Top control bar
        control_frame = ttk.LabelFrame(main_frame, text="Controls", padding=10)
        control_frame.pack(fill=tk.X, pady=(0, 10))

        btn_frame = ttk.Frame(control_frame)
        btn_frame.pack(fill=tk.X)

        self.load_btn = ttk.Button(btn_frame, text="Load Bitstream File", command=self._load_file)
        self.load_btn.pack(side=tk.LEFT, padx=5)

        self.keyboard_btn = ttk.Button(btn_frame, text="USB Reader Mode", command=self._toggle_keyboard_mode)
        self.keyboard_btn.pack(side=tk.LEFT, padx=5)

        self.save_btn = ttk.Button(btn_frame, text="Save to TXT", command=self._save_results)
        self.save_btn.pack(side=tk.LEFT, padx=5)

        self.clear_btn = ttk.Button(btn_frame, text="Clear", command=self._clear)
        self.clear_btn.pack(side=tk.LEFT, padx=5)

        # Force mode checkbox
        self.force_var = tk.BooleanVar(value=False)
        force_cb = ttk.Checkbutton(btn_frame, text="Force Mode", variable=self.force_var,
                                    command=self._on_force_toggle)
        force_cb.pack(side=tk.LEFT, padx=20)

        # Spectrum visualizer frame
        spectrum_frame = ttk.LabelFrame(main_frame, text="Audio Spectrum Visualizer (F2F Signal)", padding=10)
        spectrum_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        self.fig = Figure(figsize=(10, 4), dpi=100, facecolor=self.bg_color)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_facecolor(self.secondary_bg)
        self.ax.set_title("Magstripe F2F Signal Spectrum", color=self.accent_color, fontsize=12, fontweight='bold')
        self.ax.set_xlabel("Frequency (Hz)", color=self.fg_color, fontsize=10)
        self.ax.set_ylabel("Magnitude (dB)", color=self.fg_color, fontsize=10)
        self.ax.tick_params(colors=self.fg_color)
        self.ax.spines['bottom'].set_color(self.fg_color)
        self.ax.spines['top'].set_color(self.fg_color)
        self.ax.spines['left'].set_color(self.fg_color)
        self.ax.spines['right'].set_color(self.fg_color)

        self.canvas = FigureCanvasTkAgg(self.fig, spectrum_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # Progress bar
        self.progress_var = tk.DoubleVar(value=0)
        self.progress = ttk.Progressbar(spectrum_frame, variable=self.progress_var,
                                         maximum=1.0, mode='determinate', length=400)
        self.progress.pack(pady=(5, 0))

        # Results notebook (tabs for each track)
        results_frame = ttk.LabelFrame(main_frame, text="Decoded Track Data", padding=10)
        results_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        self.notebook = ttk.Notebook(results_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        # Track tabs
        self.track_frames = {}
        self.track_texts = {}
        for i, (name, tid) in enumerate([("Track 1 (IATA)", TrackID.Track1),
                                            ("Track 2 (ABA)", TrackID.Track2),
                                            ("Track 3 (ABA)", TrackID.Track3)], 1):
            frame = ttk.Frame(self.notebook)
            self.notebook.add(frame, text=name)

            text = scrolledtext.ScrolledText(frame, wrap=tk.WORD, font=('Consolas', 10),
                                              bg=self.secondary_bg, fg=self.fg_color,
                                              insertbackground=self.fg_color, padx=10, pady=10)
            text.pack(fill=tk.BOTH, expand=True)
            text.insert(tk.END, f"Track {i} data will appear here after parsing...\n")
            text.config(state=tk.DISABLED)

            self.track_frames[tid] = frame
            self.track_texts[tid] = text

        # Card analysis frame
        analysis_frame = ttk.LabelFrame(main_frame, text="Card Analysis", padding=10)
        analysis_frame.pack(fill=tk.X, pady=(0, 10))

        self.analysis_text = tk.Text(analysis_frame, height=6, wrap=tk.WORD,
                                    font=('Consolas', 10), bg=self.secondary_bg,
                                    fg=self.fg_color, insertbackground=self.fg_color, padx=10, pady=10)
        self.analysis_text.pack(fill=tk.BOTH, expand=True)
        self.analysis_text.insert(tk.END, "Card analysis will appear here...\n")
        self.analysis_text.config(state=tk.DISABLED)

        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = tk.Label(main_frame, textvariable=self.status_var,
                              font=('Consolas', 9), fg=self.accent_color, bg=self.bg_color,
                              anchor=tk.W)
        status_bar.pack(fill=tk.X, pady=(5, 0))

    def _setup_spectrum(self) -> None:
        """Initialize spectrum plot."""
        self.bars = self.ax.bar([], [], width=50, color=self.accent_color, alpha=0.8)
        self.ax.set_xlim(0, 5000)
        self.ax.set_ylim(0, 1)
        self.fig.tight_layout()
        self.canvas.draw()

    def _on_key_press(self, event) -> None:
        """Handle keyboard input for USB reader mode."""
        if not self.collecting:
            return

        char = event.char
        if char == '\r' or char == '\n':
            if self.keyboard_buffer:
                self._process_input(self.keyboard_buffer)
                self.keyboard_buffer = ""
                self.collecting = False
                self.keyboard_btn.config(text="USB Reader Mode")
                self.status_var.set("Card data received and parsed.")
        elif char:
            self.keyboard_buffer += char
            self.status_var.set(f"Collecting: {len(self.keyboard_buffer)} chars...")

    def _toggle_keyboard_mode(self) -> None:
        """Toggle USB keyboard reader mode."""
        if self.collecting:
            self.collecting = False
            self.keyboard_btn.config(text="USB Reader Mode")
            self.status_var.set("Keyboard mode disabled.")
        else:
            self.collecting = True
            self.keyboard_buffer = ""
            self.keyboard_btn.config(text="SWIPE NOW (ESC to cancel)")
            self.status_var.set("Keyboard mode active. Swipe your card now...")
            self.root.focus_set()

    def _on_force_toggle(self) -> None:
        """Toggle force mode."""
        self.parser.force_mode = self.force_var.get()
        self.status_var.set(f"Force mode: {'ON' if self.parser.force_mode else 'OFF'}")

    def _load_file(self) -> None:
        """Load a bitstream or keyboard data file."""
        filepath = filedialog.askopenfilename(
            title="Select Bitstream or Data File",
            filetypes=[("All files", "*.*"), ("Bitstream files", "*.bits"), ("Text files", "*.txt")]
        )
        if not filepath:
            return

        try:
            with open(filepath, 'r') as f:
                content = f.read()

            # Clean whitespace
            content = ''.join(content.split())

            # Detect if it's a bitstream or keyboard data
            if all(c in '01' for c in content):
                self._process_bitstream(content)
                self.status_var.set(f"Loaded bitstream: {len(content)} bits from {os.path.basename(filepath)}")
            else:
                self._process_input(content)
                self.status_var.set(f"Loaded keyboard data from {os.path.basename(filepath)}")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load file:\n{str(e)}")

    def _process_bitstream(self, bitstream: str) -> None:
        """Process a raw bitstream."""
        card = self.parser.parse_bitstream(bitstream)
        self.current_card = card
        self._update_display(card)
        self._start_spectrum(bitstream)

    def _process_input(self, input_str: str) -> None:
        """Process keyboard reader input."""
        card = self.parser.parse_keyboard_input(input_str)
        self.current_card = card
        self._update_display(card)

        # Generate bitstream for visualization
        bits = ""
        for c in input_str:
            if c in MagstripeParser.TRACK1_CHARS:
                idx = MagstripeParser.TRACK1_CHARS.index(c)
                parity = 1 if bin(idx).count('1') % 2 == 0 else 0
                full = (parity << 6) | idx
                for b in range(7):
                    bits += '1' if (full >> b) & 1 else '0'
            elif c in MagstripeParser.TRACK23_CHARS:
                idx = MagstripeParser.TRACK23_CHARS.index(c)
                parity = 1 if bin(idx).count('1') % 2 == 0 else 0
                full = (parity << 4) | idx
                for b in range(5):
                    bits += '1' if (full >> b) & 1 else '0'

        self._start_spectrum(bits)

    def _update_display(self, card: ParsedCard) -> None:
        """Update all display areas with parsed card data."""
        # Update track tabs
        for tid, text_widget in self.track_texts.items():
            text_widget.config(state=tk.NORMAL)
            text_widget.delete(1.0, tk.END)

            track = card.get_track(tid)
            if track:
                lines = [
                    f"{'='*50}",
                    f"  TRACK {1 if tid == TrackID.Track1 else 2 if tid == TrackID.Track2 else 3} ANALYSIS",
                    f"  Format: {'IATA (7-bit)' if tid == TrackID.Track1 else 'ABA (5-bit)'}",
                    f"{'='*50}\n",
                    f"Valid:     {'YES' if track.valid else 'NO'}",
                    f"LRC OK:    {'YES' if track.lrc_ok else 'NO'}",
                    f"\nRaw Data:",
                    f"  {track.raw}",
                ]

                if track.pan:
                    lines.extend([
                        f"\nPAN (Primary Account Number):",
                        f"  {track.pan}",
                    ])
                    if self.parser.validate_luhn(track.pan):
                        lines.append("  Luhn Check: VALID ✓")
                    else:
                        lines.append("  Luhn Check: INVALID ✗")

                if track.name:
                    lines.extend([
                        f"\nCardholder Name:",
                        f"  {track.name}",
                    ])

                if track.expiry and len(track.expiry) == 4:
                    lines.extend([
                        f"\nExpiration Date:",
                        f"  {track.expiry[2:4]}/{track.expiry[0:2]} (MM/YY)",
                    ])

                if track.service_code:
                    lines.extend([
                        f"\nService Code:",
                        f"  {track.service_code}",
                    ])

                if track.discretionary:
                    lines.extend([
                        f"\nDiscretionary Data:",
                        f"  {track.discretionary}",
                    ])

                if track.format_code:
                    lines.extend([
                        f"\nFormat Code:",
                        f"  {track.format_code}",
                    ])

                if track.start_sentinel:
                    lines.extend([
                        f"\nStart Sentinel: {track.start_sentinel}",
                        f"End Sentinel:   {track.end_sentinel}",
                    ])

                if track.error_msg:
                    lines.extend([
                        f"\nError: {track.error_msg}",
                    ])

                if track.bitstream:
                    lines.extend([
                        f"\nBitstream ({len(track.bitstream)} bits):",
                        f"  {track.bitstream[:200]}{'...' if len(track.bitstream) > 200 else ''}",
                    ])
            else:
                lines = ["No data decoded for this track.\n"]

            text_widget.insert(tk.END, "\n".join(lines) + "\n")
            text_widget.config(state=tk.DISABLED)

        # Update analysis
        self.analysis_text.config(state=tk.NORMAL)
        self.analysis_text.delete(1.0, tk.END)

        analysis_lines = [
            f"{'='*50}",
            f"  CARD ANALYSIS",
            f"{'='*50}\n",
            f"Card Type:        {card.card_type_name}",
        ]

        if card.issuing_bank:
            analysis_lines.append(f"Issuing Bank:     {card.issuing_bank}")

        if card.country:
            analysis_lines.append(f"Country:          {card.country}")

        if card.state:
            analysis_lines.append(f"State:            {card.state}")

        analysis_lines.append(f"\nTracks Present:   {len(card.tracks)}")
        for t in card.tracks:
            tid = "1" if t.track == TrackID.Track1 else "2" if t.track == TrackID.Track2 else "3"
            analysis_lines.append(f"  Track {tid}: {'VALID' if t.valid else 'INVALID'} | LRC: {'OK' if t.lrc_ok else 'FAIL'}")

        analysis_lines.append(f"\nTimestamp:        {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        self.analysis_text.insert(tk.END, "\n".join(analysis_lines) + "\n")
        self.analysis_text.config(state=tk.DISABLED)

    def _start_spectrum(self, bitstream: str) -> None:
        """Start the spectrum visualizer animation."""
        self.visualizer.load_bitstream(bitstream)

        if self.animation:
            self.animation.event_source.stop()

        self.is_animating = True
        self.animation = FuncAnimation(
            self.fig, self._update_spectrum,
            interval=50,  # 20 FPS
            blit=False,
            cache_frame_data=False
        )
        self.canvas.draw()

    def _update_spectrum(self, frame) -> None:
        """Update spectrum visualization frame."""
        if not self.is_animating:
            return

        freqs, mags, progress = self.visualizer.get_frame(advance=True)

        if len(freqs) == 0:
            return

        # Downsample for bar display
        n_bars = 64
        if len(freqs) > n_bars:
            indices = np.linspace(0, len(freqs) - 1, n_bars, dtype=int)
            freqs_display = freqs[indices]
            mags_display = mags[indices]
        else:
            freqs_display = freqs
            mags_display = mags

        # Update bars
        self.ax.clear()
        self.ax.set_facecolor(self.secondary_bg)

        # Color gradient based on frequency
        colors = []
        for f in freqs_display:
            if f < 1000:
                colors.append('#00ff88')  # Green (low freq - '0' bits)
            elif f < 2000:
                colors.append('#00d4ff')  # Cyan (mid freq)
            else:
                colors.append('#ff3366')  # Red (high freq - '1' bits)

        self.ax.bar(freqs_display, mags_display, width=(freqs_display[1] - freqs_display[0]) * 0.8,
                    color=colors, alpha=0.85, edgecolor='none')

        self.ax.set_xlim(0, 5000)
        self.ax.set_ylim(0, 1)
        self.ax.set_title("Magstripe F2F Signal Spectrum", color=self.accent_color, fontsize=12, fontweight='bold')
        self.ax.set_xlabel("Frequency (Hz)", color=self.fg_color, fontsize=10)
        self.ax.set_ylabel("Magnitude (normalized)", color=self.fg_color, fontsize=10)
        self.ax.tick_params(colors=self.fg_color)
        for spine in self.ax.spines.values():
            spine.set_color(self.fg_color)

        # Add annotation
        self.ax.text(0.98, 0.95, f"Progress: {progress*100:.1f}%",
                     transform=self.ax.transAxes, color=self.accent_color,
                     fontsize=9, ha='right', va='top',
                     bbox=dict(boxstyle='round', facecolor=self.bg_color, alpha=0.8))

        # Progress bar update
        self.progress_var.set(progress)
        self.root.update_idletasks()

    def _save_results(self) -> None:
        """Save parsed results to a text file."""
        if not self.current_card or not self.current_card.tracks:
            messagebox.showwarning("No Data", "No card data to save. Parse a card first.")
            return

        filepath = filedialog.asksaveasfilename(
            title="Save Card Analysis",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not filepath:
            return

        try:
            with open(filepath, 'w') as f:
                f.write("=" * 60 + "\n")
                f.write("  STRIPE SNOOP MODERN - CARD ANALYSIS REPORT\n")
                f.write("=" * 60 + "\n\n")
                f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Card Type: {self.current_card.card_type_name}\n")

                if self.current_card.issuing_bank:
                    f.write(f"Issuing Bank: {self.current_card.issuing_bank}\n")

                f.write("\n")

                for track in self.current_card.tracks:
                    tid = "1" if track.track == TrackID.Track1 else "2" if track.track == TrackID.Track2 else "3"
                    fmt = "IATA (7-bit)" if track.track == TrackID.Track1 else "ABA (5-bit)"

                    f.write("-" * 60 + "\n")
                    f.write(f"TRACK {tid} - {fmt}\n")
                    f.write("-" * 60 + "\n")
                    f.write(f"Valid:     {'YES' if track.valid else 'NO'}\n")
                    f.write(f"LRC OK:    {'YES' if track.lrc_ok else 'NO'}\n")
                    f.write(f"Raw Data:  {track.raw}\n")

                    if track.pan:
                        f.write(f"PAN:       {track.pan}\n")
                        f.write(f"Luhn:      {'VALID' if self.parser.validate_luhn(track.pan) else 'INVALID'}\n")
                    if track.name:
                        f.write(f"Name:      {track.name}\n")
                    if track.expiry and len(track.expiry) == 4:
                        f.write(f"Expiry:    {track.expiry[2:4]}/{track.expiry[0:2]}\n")
                    if track.service_code:
                        f.write(f"Service:   {track.service_code}\n")
                    if track.discretionary:
                        f.write(f"Discretionary: {track.discretionary}\n")
                    if track.format_code:
                        f.write(f"Format:    {track.format_code}\n")
                    f.write("\n")

                f.write("=" * 60 + "\n")
                f.write("END OF REPORT\n")

            self.status_var.set(f"Results saved to: {os.path.basename(filepath)}")
            messagebox.showinfo("Saved", f"Card analysis saved to:\n{filepath}")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to save file:\n{str(e)}")

    def _clear(self) -> None:
        """Clear all data."""
        self.current_card = None
        self.is_animating = False

        if self.animation:
            self.animation.event_source.stop()
            self.animation = None

        # Clear track tabs
        for tid, text_widget in self.track_texts.items():
            text_widget.config(state=tk.NORMAL)
            text_widget.delete(1.0, tk.END)
            text_widget.insert(tk.END, f"Track {1 if tid == TrackID.Track1 else 2 if tid == TrackID.Track2 else 3} data will appear here after parsing...\n")
            text_widget.config(state=tk.DISABLED)

        # Clear analysis
        self.analysis_text.config(state=tk.NORMAL)
        self.analysis_text.delete(1.0, tk.END)
        self.analysis_text.insert(tk.END, "Card analysis will appear here...\n")
        self.analysis_text.config(state=tk.DISABLED)

        # Clear spectrum
        self.ax.clear()
        self.ax.set_facecolor(self.secondary_bg)
        self.ax.set_title("Magstripe F2F Signal Spectrum", color=self.accent_color, fontsize=12, fontweight='bold')
        self.ax.set_xlabel("Frequency (Hz)", color=self.fg_color, fontsize=10)
        self.ax.set_ylabel("Magnitude (normalized)", color=self.fg_color, fontsize=10)
        self.ax.tick_params(colors=self.fg_color)
        for spine in self.ax.spines.values():
            spine.set_color(self.fg_color)
        self.ax.set_xlim(0, 5000)
        self.ax.set_ylim(0, 1)
        self.canvas.draw()

        self.progress_var.set(0)
        self.status_var.set("Ready. Swipe a card or load a bitstream file.")


def main():
    """Main entry point."""
    root = tk.Tk()
    app = StripeSnoopGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
