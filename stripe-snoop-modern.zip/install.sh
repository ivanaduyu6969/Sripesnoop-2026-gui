#!/bin/bash
# Stripe Snoop Modern - Quick Install Script for 64-bit Linux

set -e

echo "========================================"
echo "  Stripe Snoop Modern Installer"
echo "  64-bit Linux Magstripe Decoder"
echo "========================================"
echo ""

# Detect distro
if [ -f /etc/debian_version ]; then
    DISTRO="debian"
elif [ -f /etc/redhat-release ]; then
    DISTRO="redhat"
elif [ -f /etc/arch-release ]; then
    DISTRO="arch"
else
    DISTRO="unknown"
fi

echo "Detected distribution: $DISTRO"
echo ""

# Install system dependencies
echo "[1/4] Installing system dependencies..."
case $DISTRO in
    debian)
        sudo apt-get update
        sudo apt-get install -y build-essential cmake python3 python3-pip python3-tk
        ;;
    redhat)
        sudo dnf install -y gcc-c++ cmake python3 python3-pip python3-tkinter
        ;;
    arch)
        sudo pacman -S --needed base-devel cmake python python-pip tk
        ;;
    *)
        echo "Unknown distribution. Please install manually:"
        echo "  - C++ compiler (g++)"
        echo "  - CMake 3.16+"
        echo "  - Python 3.8+ with tkinter"
        echo "  - numpy and matplotlib (pip)"
        exit 1
        ;;
esac

# Build C++ components
echo ""
echo "[2/4] Building C++ core library and CLI..."
mkdir -p build
cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)
cd ..

# Install Python dependencies
echo ""
echo "[3/4] Installing Python dependencies..."
pip3 install --user -r python/requirements.txt

# Install binaries
echo ""
echo "[4/4] Installing binaries..."
sudo install -Dm755 build/ss /usr/local/bin/ss-modern
sudo install -Dm644 include/stripe_snoop_core.hpp /usr/local/include/stripesnoop/stripe_snoop_core.hpp

# Create desktop entry for GUI
mkdir -p ~/.local/share/applications
cat > ~/.local/share/applications/stripe-snoop-modern.desktop << 'EOF'
[Desktop Entry]
Name=Stripe Snoop Modern
Comment=64-bit Linux Magstripe Decoder
Exec=python3 %s/python/stripe_snoop_gui.py
Icon=utilities-terminal
Type=Application
Terminal=false
Categories=Utility;Security;
EOF

echo ""
echo "========================================"
echo "  Installation Complete!"
echo "========================================"
echo ""
echo "Usage:"
echo "  CLI:    ss-modern --help"
echo "  GUI:    python3 python/stripe_snoop_gui.py"
echo ""
echo "Run the GUI now? (y/n)"
read -r response
if [ "$response" = "y" ] || [ "$response" = "Y" ]; then
    python3 python/stripe_snoop_gui.py
fi
