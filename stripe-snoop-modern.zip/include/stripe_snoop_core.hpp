// stripe_snoop_core.hpp
// Modernized Stripe Snoop - 64-bit Linux Magstripe Parser
// Based on original stripe-snoop by Acidus (acidus@yak.net)
// License: GPL-3.0+

#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <optional>
#include <memory>
#include <stdexcept>

namespace stripesnoop {

// ============================================================================
// Data Structures
// ============================================================================

enum class TrackID { Track1, Track2, Track3 };

enum class ParityType { Even, Odd };

enum class CardType {
    Unknown,
    Visa,
    MasterCard,
    Amex,
    Discover,
    DinersClub,
    JCB,
    DriversLicense,
    StudentID,
    GiftCard,
    HotelKey,
    Banking,
    Other
};

struct TrackData {
    TrackID track;
    std::string raw;           // Raw decoded characters
    std::string bitstream;     // Original bitstream (as string of '0'/'1')
    bool valid = false;
    bool lrc_ok = false;
    std::string error_msg;

    // Track 1 specific (IATA format)
    std::string format_code;   // 'A'-'Z'
    std::string pan;           // Primary Account Number
    std::string name;          // Cardholder name
    std::string expiry;        // YYMM
    std::string service_code;  // 3 digits
    std::string discretionary; // Discretionary data

    // Track 2/3 specific (ABA format)
    std::string start_sentinel;
    std::string end_sentinel;
};

struct ParsedCard {
    std::vector<TrackData> tracks;
    CardType card_type = CardType::Unknown;
    std::string card_type_name;
    std::string issuing_bank;
    std::string country;
    std::string state;

    bool has_track(TrackID t) const;
    std::optional<TrackData> get_track(TrackID t) const;
};

// ============================================================================
// Signal Processing
// ============================================================================

class F2FDecoder {
public:
    // Decode F2F (Aiken Biphase) bitstream to raw bytes/bits
    // threshold: pulse width threshold for distinguishing 0 vs 1
    static std::string decode(const std::vector<double>& pulse_widths, double clock_freq);

    // Generate simulated audio waveform from bitstream for visualization
    static std::vector<double> generate_waveform(
        const std::string& bitstream,
        double sample_rate = 44100.0,
        double bit_rate = 1000.0,    // bits per second (typical swipe speed)
        double freq0 = 1000.0,       // Hz for '0' (one flux reversal per bit)
        double freq1 = 2000.0        // Hz for '1' (two flux reversals per bit)
    );
};

// ============================================================================
// Track Parsers
// ============================================================================

class TrackParser {
public:
    virtual ~TrackParser() = default;
    virtual TrackData parse(const std::string& bitstream) const = 0;
    virtual size_t bits_per_char() const = 0;
};

class Track1Parser : public TrackParser {
public:
    TrackData parse(const std::string& bitstream) const override;
    size_t bits_per_char() const override { return 7; }  // 6 data + 1 parity
};

class Track2Parser : public TrackParser {
public:
    TrackData parse(const std::string& bitstream) const override;
    size_t bits_per_char() const override { return 5; }  // 4 data + 1 parity
};

class Track3Parser : public TrackParser {
public:
    TrackData parse(const std::string& bitstream) const override;
    size_t bits_per_char() const override { return 5; }  // 4 data + 1 parity
};

// ============================================================================
// Card Analyzer
// ============================================================================

class CardAnalyzer {
public:
    static CardType analyze(const ParsedCard& card);
    static std::string get_card_name(CardType type);
    static std::string get_issuing_bank(const std::string& pan);
    static bool validate_luhn(const std::string& pan);
};

// ============================================================================
// Main API
// ============================================================================

class StripeSnoop {
public:
    StripeSnoop();
    ~StripeSnoop();

    // Parse from raw bitstream string ("010101...")
    ParsedCard parse_bitstream(const std::string& bitstream, TrackID track_hint = TrackID::Track2);

    // Parse from keyboard-emulating reader input
    // e.g., "%B1234567890123456^DOE/JOHN^2512...?;1234567890123456=2512...?"
    ParsedCard parse_keyboard_input(const std::string& input);

    // Parse from raw binary data (for serial/USB readers)
    ParsedCard parse_raw_bytes(const std::vector<uint8_t>& data);

    // Force mode: try to parse even with errors
    void set_force_mode(bool enabled) { force_mode_ = enabled; }
    void set_verbose(bool enabled) { verbose_ = enabled; }

private:
    bool force_mode_ = false;
    bool verbose_ = false;
    std::unique_ptr<TrackParser> parsers_[3];
};

// ============================================================================
// Utilities
// ============================================================================

namespace utils {
    // Convert bitstream string to byte vector
    std::vector<uint8_t> bits_to_bytes(const std::string& bits);

    // Calculate LRC (Longitudinal Redundancy Check)
    uint8_t calculate_lrc(const std::vector<uint8_t>& data);

    // Check parity
    bool check_parity(uint8_t value, size_t bits, ParityType type);

    // Hex dump for debugging
    std::string hexdump(const std::vector<uint8_t>& data);

    // Bank identification from BIN (first 6 digits of PAN)
    std::string lookup_bank(uint32_t bin);
}

} // namespace stripesnoop
