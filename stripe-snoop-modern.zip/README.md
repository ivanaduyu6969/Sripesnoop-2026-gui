# Stripe Snoop Modern

**Modernized 64-bit Linux Magstripe Decoder with Audio Spectrum Visualizer**

Based on the original [Stripe Snoop](https://github.com/Steven-Cai/stripe-snoop) by Acidus (acidus@yak.net), this is a complete modernization for contemporary 64-bit Linux systems.

---

## What's New

| Feature | Original (2005) | Modern (2026) |
|---------|----------------|---------------|
| Architecture | 32-bit x86 | **64-bit x86_64** |
| I/O | Direct port access (root required) | **USB HID / File input** |
| Build System | Legacy Makefiles | **CMake 3.16+ / Modern Makefile** |
| Language | C++98 | **C++20** |
| GUI | None (CLI only) | **Full GUI with spectrum visualizer** |
| Hardware | Game port / Parallel port | **USB keyboard-emulating readers** |
| Visualization | None | **Real-time audio spectrum FFT** |
| Output | stdout only | **Save to TXT with all track info** |

---

## Features

- **Modern C++20 Core Library** - Clean, type-safe, 64-bit architecture
- **USB Reader Support** - Works with modern USB HID keyboard-emulating magstripe readers (no root required)
- **Audio Spectrum Visualizer** - Real-time FFT visualization of the F2F encoded signal
- **Track 1/2/3 Parsing** - Full IATA (7-bit) and ABA (5-bit) decoding with LRC validation
- **Card Type Detection** - Auto-detects Visa, MasterCard, Amex, Discover, JCB, driver's licenses
- **Luhn Validation** - Credit card PAN checksum verification
- **Save to TXT** - Export all decoded track data to a formatted text file
- **Dark Theme GUI** - Modern tkinter interface with matplotlib visualization
- **Force Mode** - Parse damaged or non-standard magstripes
- **Raw Bitstream Support** - Analyze captured bitstream files

---

## Quick Start

### Prerequisites

```bash
# Debian/Ubuntu
sudo apt-get update
sudo apt-get install build-essential cmake python3 python3-pip python3-tk

# Fedora/RHEL
sudo dnf install gcc-c++ cmake python3 python3-pip python3-tkinter

# Arch
sudo pacman -S base-devel cmake python python-pip tk
```

### Build C++ CLI

```bash
cd stripe-snoop-modern

# Using CMake (recommended)
mkdir build && cd build
cmake ..
make -j$(nproc)
sudo make install

# Or using Makefile directly
make
```

### Run Python GUI

```bash
cd stripe-snoop-modern/python
pip3 install -r requirements.txt
python3 stripe_snoop_gui.py
```

---

## Usage

### GUI Mode (Recommended)

```bash
python3 python/stripe_snoop_gui.py
```

The GUI provides:
- **Load Bitstream File** - Open captured raw bitstream files
- **USB Reader Mode** - Swipe a card with a USB HID reader
- **Audio Spectrum Visualizer** - Real-time FFT of the F2F signal
- **Track Tabs** - Decoded data for Tracks 1, 2, and 3
- **Card Analysis Panel** - Auto-detected card type and bank
- **Save to TXT** - Export all track information

### CLI Mode

```bash
# Parse a bitstream file
./ss -i samples/track2_sample.bits -o result.txt

# USB keyboard reader mode
./ss -k
# (swipe card when prompted)

# Force mode for damaged tracks
./ss -f -i damaged.bits

# Export audio waveform
./ss -i track.bits -w audio.raw
# (play with: aplay -f S16_LE -r 44100 audio.raw)

# Full help
./ss --help
```

---

## Architecture

```
stripe-snoop-modern/
├── include/
│   └── stripe_snoop_core.hpp      # Modern C++20 API
├── src/
│   ├── stripe_snoop_core.cpp       # Parser implementation
│   └── stripe_snoop_cli.cpp        # CLI application
├── python/
│   ├── stripe_snoop_gui.py         # GUI application
│   └── requirements.txt            # Python dependencies
├── samples/
│   ├── track2_sample.bits          # Sample bitstream
│   └── sample_keyboard.txt         # Sample USB reader output
├── CMakeLists.txt                  # Modern CMake build
├── Makefile                        # Quick build
└── README.md                       # This file
```

---

## Technical Details

### F2F (Aiken Biphase) Encoding

Magstripe data uses Frequency/Double Frequency (F2F) encoding:
- **'0' bit**: One flux reversal per bit cell (~1 kHz)
- **'1' bit**: Two flux reversals per bit cell (~2 kHz)

The spectrum visualizer computes the FFT of the simulated signal, showing these frequency components in real-time as the card is "swiped."

### Track Formats

| Track | Format | Bits/Char | Max Chars | Start | End |
|-------|--------|-----------|-----------|-------|-----|
| 1 | IATA | 7 (6+parity) | 79 | `%` | `?` |
| 2 | ABA | 5 (4+parity) | 40 | `;` | `?` |
| 3 | ABA | 5 (4+parity) | 107 | `;` | `?` |

### USB Reader Protocol

Modern USB magstripe readers appear as HID keyboards. A typical swipe outputs:
```
%B1234567890123456^DOE/JOHN^251210100000000000000?;1234567890123456=25121010000000000000?
```

Track 1 starts with `%`, Track 2 starts with `;`, both end with `?`.

---

## Hardware Compatibility

### Supported Readers

| Interface | Support | Notes |
|-----------|---------|-------|
| USB HID Keyboard | **Full** | Plug-and-play, no drivers |
| USB Serial (RS232) | Partial | Use `cat /dev/ttyUSB0` |
| Audio Jack Readers | **Full** | Capture with `arecord` |
| Legacy Game Port | **Removed** | No longer supported by Linux |
| Legacy Parallel Port | **Removed** | Use USB adapters instead |

### Recommended Hardware

- **MSR90** or **MSR605X** USB HID readers (~$15-30)
- Any reader that outputs keyboard emulation

---

## License

GPL-3.0+ (same as original Stripe Snoop)

Original work by Acidus (acidus@yak.net)  
Modernized for 64-bit Linux systems

---

## Acknowledgments

- Acidus for the original Stripe Snoop project
- The magstripe research community
- AAMVA for driver's license track format specifications
