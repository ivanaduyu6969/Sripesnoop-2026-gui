// stripe_snoop_cli.cpp
// Modern CLI for Stripe Snoop - 64-bit Linux

#include "stripe_snoop_core.hpp"
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <getopt.h>

using namespace stripesnoop;

void print_usage(const char* prog) {
    std::cout << "Stripe Snoop Modern - 64-bit Linux Magstripe Decoder\n";
    std::cout << "Usage: " << prog << " [OPTIONS] [input]\n\n";
    std::cout << "Options:\n";
    std::cout << "  -i, --input FILE      Read bitstream from file\n";
    std::cout << "  -k, --keyboard        Read from keyboard (USB reader)\n";
    std::cout << "  -1, --track1          Parse as Track 1 (IATA)\n";
    std::cout << "  -2, --track2          Parse as Track 2 (ABA)\n";
    std::cout << "  -3, --track3          Parse as Track 3 (ABA)\n";
    std::cout << "  -f, --force           Force mode (ignore errors)\n";
    std::cout << "  -v, --verbose         Verbose output\n";
    std::cout << "  -o, --output FILE     Save results to text file\n";
    std::cout << "  -w, --waveform FILE   Export audio waveform to raw file\n";
    std::cout << "  -h, --help            Show this help\n";
    std::cout << "\nExamples:\n";
    std::cout << "  " << prog << " -i track2.bits\n";
    std::cout << "  " << prog << " -k                    # Swipe card when prompted\n";
    std::cout << "  echo "010101..." | " << prog << " -2\n";
    std::cout << "  " << prog << " -i raw.bits -o result.txt -w audio.raw\n";
}

void print_card(const ParsedCard& card, bool verbose) {
    std::cout << "\n========================================\n";
    std::cout << "Stripe Snoop Modern - Card Analysis\n";
    std::cout << "========================================\n";

    std::cout << "Card Type: " << card.card_type_name << "\n";
    if (!card.issuing_bank.empty() && card.issuing_bank != "Unknown Bank") {
        std::cout << "Issuing Bank: " << card.issuing_bank << "\n";
    }

    for (const auto& track : card.tracks) {
        std::cout << "\n--- Track " << (track.track == TrackID::Track1 ? "1" :
                                          track.track == TrackID::Track2 ? "2" : "3")
                  << " (" << (track.track == TrackID::Track1 ? "IATA" : "ABA") << ") ---\n";

        std::cout << "Valid: " << (track.valid ? "YES" : "NO") << "\n";
        std::cout << "LRC OK: " << (track.lrc_ok ? "YES" : "NO") << "\n";

        if (!track.error_msg.empty()) {
            std::cout << "Error: " << track.error_msg << "\n";
        }

        std::cout << "Raw Data: " << track.raw << "\n";

        if (!track.pan.empty()) {
            std::cout << "PAN: " << track.pan << "\n";
            if (CardAnalyzer::validate_luhn(track.pan)) {
                std::cout << "Luhn Check: VALID\n";
            } else {
                std::cout << "Luhn Check: INVALID\n";
            }
        }

        if (!track.name.empty()) {
            std::cout << "Name: " << track.name << "\n";
        }

        if (!track.expiry.empty() && track.expiry.length() == 4) {
            std::cout << "Expiry: " << track.expiry.substr(2, 2) << "/" << track.expiry.substr(0, 2) << "\n";
        }

        if (!track.service_code.empty()) {
            std::cout << "Service Code: " << track.service_code << "\n";
        }

        if (!track.discretionary.empty()) {
            std::cout << "Discretionary Data: " << track.discretionary << "\n";
        }

        if (verbose) {
            std::cout << "Bitstream length: " << track.bitstream.length() << " bits\n";
            std::cout << "Start Sentinel: " << track.start_sentinel << "\n";
            std::cout << "End Sentinel: " << track.end_sentinel << "\n";
        }
    }

    std::cout << "\n========================================\n";
}

bool save_to_file(const ParsedCard& card, const std::string& filename) {
    std::ofstream out(filename);
    if (!out) return false;

    out << "Stripe Snoop Modern - Card Analysis Report\n";
    out << "Generated: " << __DATE__ << " " << __TIME__ << "\n";
    out << "========================================\n\n";

    out << "Card Type: " << card.card_type_name << "\n";
    if (!card.issuing_bank.empty()) {
        out << "Issuing Bank: " << card.issuing_bank << "\n";
    }
    out << "\n";

    for (const auto& track : card.tracks) {
        out << "--- TRACK " << (track.track == TrackID::Track1 ? "1" :
                                track.track == TrackID::Track2 ? "2" : "3")
            << " ---\n";
        out << "Format: " << (track.track == TrackID::Track1 ? "IATA (7-bit)" : "ABA (5-bit)") << "\n";
        out << "Valid: " << (track.valid ? "YES" : "NO") << "\n";
        out << "LRC OK: " << (track.lrc_ok ? "YES" : "NO") << "\n";
        out << "Raw: " << track.raw << "\n";

        if (!track.pan.empty()) out << "PAN: " << track.pan << "\n";
        if (!track.name.empty()) out << "Name: " << track.name << "\n";
        if (!track.expiry.empty()) out << "Expiry: " << track.expiry << "\n";
        if (!track.service_code.empty()) out << "Service Code: " << track.service_code << "\n";
        if (!track.discretionary.empty()) out << "Discretionary: " << track.discretionary << "\n";
        out << "\n";
    }

    out.close();
    return true;
}

bool save_waveform(const std::vector<double>& waveform, const std::string& filename) {
    std::ofstream out(filename, std::ios::binary);
    if (!out) return false;

    // Save as 16-bit PCM raw audio
    for (double sample : waveform) {
        int16_t pcm = static_cast<int16_t>(sample * 32767.0);
        out.write(reinterpret_cast<const char*>(&pcm), sizeof(pcm));
    }

    out.close();
    return true;
}

int main(int argc, char* argv[]) {
    const char* short_opts = "i:k123fvo:w:h";
    static struct option long_opts[] = {
        {"input", required_argument, nullptr, 'i'},
        {"keyboard", no_argument, nullptr, 'k'},
        {"track1", no_argument, nullptr, '1'},
        {"track2", no_argument, nullptr, '2'},
        {"track3", no_argument, nullptr, '3'},
        {"force", no_argument, nullptr, 'f'},
        {"verbose", no_argument, nullptr, 'v'},
        {"output", required_argument, nullptr, 'o'},
        {"waveform", required_argument, nullptr, 'w'},
        {"help", no_argument, nullptr, 'h'},
        {nullptr, 0, nullptr, 0}
    };

    std::string input_file;
    std::string output_file;
    std::string waveform_file;
    bool keyboard_mode = false;
    bool force_mode = false;
    bool verbose = false;
    TrackID track_hint = TrackID::Track2;

    int opt;
    while ((opt = getopt_long(argc, argv, short_opts, long_opts, nullptr)) != -1) {
        switch (opt) {
            case 'i': input_file = optarg; break;
            case 'k': keyboard_mode = true; break;
            case '1': track_hint = TrackID::Track1; break;
            case '2': track_hint = TrackID::Track2; break;
            case '3': track_hint = TrackID::Track3; break;
            case 'f': force_mode = true; break;
            case 'v': verbose = true; break;
            case 'o': output_file = optarg; break;
            case 'w': waveform_file = optarg; break;
            case 'h':
            default:
                print_usage(argv[0]);
                return (opt == 'h') ? 0 : 1;
        }
    }

    StripeSnoop snoop;
    snoop.set_force_mode(force_mode);
    snoop.set_verbose(verbose);

    ParsedCard card;
    std::string bitstream;

    if (keyboard_mode) {
        std::cout << "Stripe Snoop Modern - Keyboard Reader Mode\n";
        std::cout << "Please swipe your card now...\n";
        std::string input;
        std::getline(std::cin, input);
        card = snoop.parse_keyboard_input(input);
    } else if (!input_file.empty()) {
        std::ifstream in(input_file);
        if (!in) {
            std::cerr << "Error: Cannot open input file: " << input_file << "\n";
            return 1;
        }
        std::string content((std::istreambuf_iterator<char>(in)),
                               std::istreambuf_iterator<char>());
        in.close();

        // Remove whitespace
        content.erase(std::remove_if(content.begin(), content.end(), ::isspace), content.end());

        // Check if it's a bitstream or keyboard data
        bool all_bits = std::all_of(content.begin(), content.end(), 
                                    [](char c) { return c == '0' || c == '1'; });

        if (all_bits) {
            card = snoop.parse_bitstream(content, track_hint);
            bitstream = content;
        } else {
            card = snoop.parse_keyboard_input(content);
        }
    } else {
        // Read from stdin
        std::string content((std::istreambuf_iterator<char>(std::cin)),
                             std::istreambuf_iterator<char>());

        content.erase(std::remove_if(content.begin(), content.end(), ::isspace), content.end());

        bool all_bits = std::all_of(content.begin(), content.end(),
                                    [](char c) { return c == '0' || c == '1'; });

        if (all_bits) {
            card = snoop.parse_bitstream(content, track_hint);
            bitstream = content;
        } else {
            card = snoop.parse_keyboard_input(content);
        }
    }

    print_card(card, verbose);

    if (!output_file.empty()) {
        if (save_to_file(card, output_file)) {
            std::cout << "\nResults saved to: " << output_file << "\n";
        } else {
            std::cerr << "Error: Cannot write to " << output_file << "\n";
        }
    }

    if (!waveform_file.empty() && !bitstream.empty()) {
        auto waveform = F2FDecoder::generate_waveform(bitstream);
        if (save_waveform(waveform, waveform_file)) {
            std::cout << "Waveform saved to: " << waveform_file << " (16-bit PCM raw)\n";
        } else {
            std::cerr << "Error: Cannot write waveform to " << waveform_file << "\n";
        }
    }

    return 0;
}
