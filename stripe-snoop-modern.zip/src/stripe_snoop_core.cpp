// stripe_snoop_core.cpp
// Modernized Stripe Snoop - 64-bit Linux Magstripe Parser Implementation

#include "stripe_snoop_core.hpp"
#include <algorithm>
#include <cmath>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <cstring>

namespace stripesnoop {

// ============================================================================
// Character Tables
// ============================================================================

// Track 1: IATA 6-bit + odd parity (7 bits total)
// Characters 0x20-0x5F (space through underscore)
static const char TRACK1_CHARS[64] = {
    ' ', '!', '"', '#', '$', '%', '&', ''',
    '(', ')', '*', '+', ',', '-', '.', '/',
    '0', '1', '2', '3', '4', '5', '6', '7',
    '8', '9', ':', ';', '<', '=', '>', '?',
    '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
    'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
    'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W',
    'X', 'Y', 'Z', '[', '\\', ']', '^', '_'
};

// Track 2/3: ABA 4-bit + odd parity (5 bits total)
static const char TRACK23_CHARS[16] = {
    '0', '1', '2', '3', '4', '5', '6', '7',
    '8', '9', ':', ';', '<', '=', '>', '?'
};

// ============================================================================
// ParsedCard Implementation
// ============================================================================

bool ParsedCard::has_track(TrackID t) const {
    for (const auto& tr : tracks) {
        if (tr.track == t) return true;
    }
    return false;
}

std::optional<TrackData> ParsedCard::get_track(TrackID t) const {
    for (const auto& tr : tracks) {
        if (tr.track == t) return tr;
    }
    return std::nullopt;
}

// ============================================================================
// F2F Decoder
// ============================================================================

std::string F2FDecoder::decode(const std::vector<double>& pulse_widths, double clock_freq) {
    std::string bits;
    double threshold = 1.5; // 1x clock = 0, 2x clock = 1

    for (double pw : pulse_widths) {
        double ratio = pw * clock_freq;
        if (ratio < threshold) {
            bits += '0';
        } else {
            bits += '1';
        }
    }
    return bits;
}

std::vector<double> F2FDecoder::generate_waveform(
    const std::string& bitstream,
    double sample_rate,
    double bit_rate,
    double freq0,
    double freq1
) {
    if (bitstream.empty()) return {};

    double bit_duration = 1.0 / bit_rate;
    size_t samples_per_bit = static_cast<size_t>(sample_rate * bit_duration);
    size_t total_samples = bitstream.length() * samples_per_bit;

    std::vector<double> waveform;
    waveform.reserve(total_samples);

    for (char bit : bitstream) {
        double freq = (bit == '1') ? freq1 : freq0;
        // F2F: each bit cell has flux reversals
        // For '0': one cycle per bit cell (one flux reversal at center)
        // For '1': two cycles per bit cell (flux reversals at 1/4 and 3/4)

        for (size_t s = 0; s < samples_per_bit; ++s) {
            double t = static_cast<double>(s) / sample_rate;
            double phase = 2.0 * M_PI * freq * t;

            // Generate square wave-ish signal with harmonics
            double sample = 0.0;
            if (bit == '1') {
                // Two flux reversals per bit cell
                sample = (std::sin(phase) > 0) ? 0.8 : -0.8;
            } else {
                // One flux reversal per bit cell
                sample = (std::sin(phase * 0.5) > 0) ? 0.8 : -0.8;
            }

            // Add some noise for realism
            sample += 0.05 * ((static_cast<double>(rand()) / RAND_MAX) - 0.5);

            waveform.push_back(sample);
        }
    }

    return waveform;
}

// ============================================================================
// Track 1 Parser (IATA Format)
// ============================================================================

TrackData Track1Parser::parse(const std::string& bitstream) const {
    TrackData result;
    result.track = TrackID::Track1;
    result.bitstream = bitstream;

    if (bitstream.length() < 7) {
        result.error_msg = "Bitstream too short for Track 1";
        return result;
    }

    // Track 1: 7 bits per char (6 data + 1 odd parity)
    std::string decoded;
    std::vector<uint8_t> raw_bytes;

    for (size_t i = 0; i + 6 < bitstream.length(); i += 7) {
        uint8_t byte = 0;
        for (size_t j = 0; j < 7; ++j) {
            if (bitstream[i + j] == '1') {
                byte |= (1 << j);
            }
        }

        // Check odd parity (bit 6 is parity)
        uint8_t data_bits = byte & 0x3F;
        uint8_t parity_bit = (byte >> 6) & 0x01;
        uint8_t parity_count = __builtin_popcount(data_bits);

        if ((parity_count % 2) == parity_bit) {
            // Parity error - but continue in force mode
            // For now, just decode anyway
        }

        if (data_bits < 64) {
            char c = TRACK1_CHARS[data_bits];
            decoded += c;
            raw_bytes.push_back(data_bits);
        }
    }

    result.raw = decoded;

    // Parse Track 1 fields
    // Format: %B PAN ^ NAME ^ YYMM SERVICE discretionary ? LRC
    if (decoded.length() > 0 && decoded[0] == '%') {
        result.start_sentinel = "%";
        result.format_code = (decoded.length() > 1) ? decoded.substr(1, 1) : "";

        // Find field separators (^)
        size_t first_sep = decoded.find('^');
        if (first_sep != std::string::npos) {
            result.pan = decoded.substr(1, first_sep - 1);
            if (result.pan.length() > 0 && std::isalpha(result.pan[0])) {
                result.format_code = result.pan.substr(0, 1);
                result.pan = result.pan.substr(1);
            }

            size_t second_sep = decoded.find('^', first_sep + 1);
            if (second_sep != std::string::npos) {
                result.name = decoded.substr(first_sep + 1, second_sep - first_sep - 1);

                size_t end_sentinel = decoded.find('?', second_sep);
                if (end_sentinel != std::string::npos) {
                    result.end_sentinel = "?";
                    std::string remaining = decoded.substr(second_sep + 1, end_sentinel - second_sep - 1);
                    if (remaining.length() >= 4) {
                        result.expiry = remaining.substr(0, 4);
                        if (remaining.length() >= 7) {
                            result.service_code = remaining.substr(4, 3);
                            result.discretionary = remaining.substr(7);
                        }
                    }
                }
            }
        }
        result.valid = true;
    } else {
        result.error_msg = "Missing start sentinel (%)";
    }

    // Calculate LRC
    if (raw_bytes.size() > 0) {
        uint8_t lrc = utils::calculate_lrc(raw_bytes);
        result.lrc_ok = (lrc == 0);
    }

    return result;
}

// ============================================================================
// Track 2 Parser (ABA Format)
// ============================================================================

TrackData Track2Parser::parse(const std::string& bitstream) const {
    TrackData result;
    result.track = TrackID::Track2;
    result.bitstream = bitstream;

    if (bitstream.length() < 5) {
        result.error_msg = "Bitstream too short for Track 2";
        return result;
    }

    // Track 2: 5 bits per char (4 data + 1 odd parity)
    std::string decoded;
    std::vector<uint8_t> raw_bytes;

    for (size_t i = 0; i + 4 < bitstream.length(); i += 5) {
        uint8_t byte = 0;
        for (size_t j = 0; j < 5; ++j) {
            if (bitstream[i + j] == '1') {
                byte |= (1 << j);
            }
        }

        uint8_t data_bits = byte & 0x0F;
        uint8_t parity_bit = (byte >> 4) & 0x01;
        uint8_t parity_count = __builtin_popcount(data_bits);

        if (data_bits < 16) {
            char c = TRACK23_CHARS[data_bits];
            decoded += c;
            raw_bytes.push_back(data_bits);
        }
    }

    result.raw = decoded;

    // Parse Track 2 fields
    // Format: ; PAN = YYMM SERVICE discretionary ? LRC
    if (decoded.length() > 0 && decoded[0] == ';') {
        result.start_sentinel = ";";

        size_t sep = decoded.find('=');
        if (sep != std::string::npos) {
            result.pan = decoded.substr(1, sep - 1);

            size_t end_sentinel = decoded.find('?', sep);
            if (end_sentinel != std::string::npos) {
                result.end_sentinel = "?";
                std::string remaining = decoded.substr(sep + 1, end_sentinel - sep - 1);
                if (remaining.length() >= 4) {
                    result.expiry = remaining.substr(0, 4);
                    if (remaining.length() >= 7) {
                        result.service_code = remaining.substr(4, 3);
                        result.discretionary = remaining.substr(7);
                    }
                }
            }
        }
        result.valid = true;
    } else {
        result.error_msg = "Missing start sentinel (;)";
    }

    if (raw_bytes.size() > 0) {
        uint8_t lrc = utils::calculate_lrc(raw_bytes);
        result.lrc_ok = (lrc == 0);
    }

    return result;
}

// ============================================================================
// Track 3 Parser (ABA Format - same as Track 2)
// ============================================================================

TrackData Track3Parser::parse(const std::string& bitstream) const {
    TrackData result;
    result.track = TrackID::Track3;
    result.bitstream = bitstream;

    if (bitstream.length() < 5) {
        result.error_msg = "Bitstream too short for Track 3";
        return result;
    }

    std::string decoded;
    std::vector<uint8_t> raw_bytes;

    for (size_t i = 0; i + 4 < bitstream.length(); i += 5) {
        uint8_t byte = 0;
        for (size_t j = 0; j < 5; ++j) {
            if (bitstream[i + j] == '1') {
                byte |= (1 << j);
            }
        }

        uint8_t data_bits = byte & 0x0F;
        if (data_bits < 16) {
            char c = TRACK23_CHARS[data_bits];
            decoded += c;
            raw_bytes.push_back(data_bits);
        }
    }

    result.raw = decoded;

    if (decoded.length() > 0 && decoded[0] == ';') {
        result.start_sentinel = ";";
        result.valid = true;
    }

    if (raw_bytes.size() > 0) {
        uint8_t lrc = utils::calculate_lrc(raw_bytes);
        result.lrc_ok = (lrc == 0);
    }

    return result;
}

// ============================================================================
// Card Analyzer
// ============================================================================

CardType CardAnalyzer::analyze(const ParsedCard& card) {
    auto t1 = card.get_track(TrackID::Track1);
    auto t2 = card.get_track(TrackID::Track2);

    std::string pan;
    if (t2 && !t2->pan.empty()) {
        pan = t2->pan;
    } else if (t1 && !t1->pan.empty()) {
        pan = t1->pan;
    }

    if (pan.empty()) return CardType::Unknown;

    // Credit card identification by IIN (Issuer Identification Number)
    if (pan.length() >= 2) {
        int prefix2 = std::stoi(pan.substr(0, 2));
        int prefix1 = pan[0] - '0';
        int prefix4 = (pan.length() >= 4) ? std::stoi(pan.substr(0, 4)) : 0;

        if (prefix1 == 4) return CardType::Visa;
        if (prefix2 >= 51 && prefix2 <= 55) return CardType::MasterCard;
        if (prefix2 == 34 || prefix2 == 37) return CardType::Amex;
        if (prefix4 == 6011 || prefix2 == 65) return CardType::Discover;
        if (prefix2 == 36) return CardType::DinersClub;
        if (prefix2 == 35) return CardType::JCB;
    }

    // Driver's license detection (Track 1 starts with specific format codes)
    if (t1 && !t1->raw.empty()) {
        if (t1->raw.find("%A") == 0 || t1->raw.find("%B") == 0 || t1->raw.find("%C") == 0) {
            // AAMVA format - likely driver's license
            if (t1->raw.find("^DCS") != std::string::npos ||
                t1->raw.find("^DCT") != std::string::npos) {
                return CardType::DriversLicense;
            }
        }
    }

    return CardType::Unknown;
}

std::string CardAnalyzer::get_card_name(CardType type) {
    switch (type) {
        case CardType::Visa: return "Visa";
        case CardType::MasterCard: return "MasterCard";
        case CardType::Amex: return "American Express";
        case CardType::Discover: return "Discover";
        case CardType::DinersClub: return "Diners Club";
        case CardType::JCB: return "JCB";
        case CardType::DriversLicense: return "Driver's License";
        case CardType::StudentID: return "Student ID";
        case CardType::GiftCard: return "Gift Card";
        case CardType::HotelKey: return "Hotel Key Card";
        case CardType::Banking: return "Banking Card";
        case CardType::Other: return "Other";
        default: return "Unknown";
    }
}

std::string CardAnalyzer::get_issuing_bank(const std::string& pan) {
    if (pan.length() < 6) return "Unknown";

    uint32_t bin = std::stoul(pan.substr(0, 6));
    return utils::lookup_bank(bin);
}

bool CardAnalyzer::validate_luhn(const std::string& pan) {
    int sum = 0;
    bool alternate = false;

    for (int i = static_cast<int>(pan.length()) - 1; i >= 0; --i) {
        int n = pan[i] - '0';
        if (n < 0 || n > 9) continue; // Skip non-digits

        if (alternate) {
            n *= 2;
            if (n > 9) n -= 9;
        }
        sum += n;
        alternate = !alternate;
    }

    return (sum % 10) == 0;
}

// ============================================================================
// StripeSnoop Main API
// ============================================================================

StripeSnoop::StripeSnoop() {
    parsers_[0] = std::make_unique<Track1Parser>();
    parsers_[1] = std::make_unique<Track2Parser>();
    parsers_[2] = std::make_unique<Track3Parser>();
}

StripeSnoop::~StripeSnoop() = default;

ParsedCard StripeSnoop::parse_bitstream(const std::string& bitstream, TrackID track_hint) {
    ParsedCard card;

    // Try to auto-detect track based on bit length patterns
    size_t len = bitstream.length();

    // Try all three tracks and see which one parses best
    std::vector<TrackData> candidates;

    for (int i = 0; i < 3; ++i) {
        auto& parser = parsers_[i];
        size_t bpc = parser->bits_per_char();

        // Check if bitstream length is compatible
        if (len >= bpc && (len % bpc) == 0) {
            TrackData td = parser->parse(bitstream);
            if (td.valid || force_mode_) {
                candidates.push_back(td);
            }
        }
    }

    // If no valid candidate, try the hinted track
    if (candidates.empty()) {
        int idx = (track_hint == TrackID::Track1) ? 0 : 
                  (track_hint == TrackID::Track2) ? 1 : 2;
        TrackData td = parsers_[idx]->parse(bitstream);
        if (force_mode_ || td.valid) {
            candidates.push_back(td);
        }
    }

    card.tracks = candidates;
    card.card_type = CardAnalyzer::analyze(card);
    card.card_type_name = CardAnalyzer::get_card_name(card.card_type);

    auto t2 = card.get_track(TrackID::Track2);
    auto t1 = card.get_track(TrackID::Track1);
    if (t2 && !t2->pan.empty()) {
        card.issuing_bank = CardAnalyzer::get_issuing_bank(t2->pan);
    } else if (t1 && !t1->pan.empty()) {
        card.issuing_bank = CardAnalyzer::get_issuing_bank(t1->pan);
    }

    return card;
}

ParsedCard StripeSnoop::parse_keyboard_input(const std::string& input) {
    ParsedCard card;

    // USB keyboard-emulating readers output something like:
    // %B1234567890123456^DOE/JOHN^251210100000000000000?;1234567890123456=25121010000000000000?

    // Split by track start sentinels
    size_t pos = 0;

    // Track 1 starts with '%'
    size_t t1_start = input.find('%');
    if (t1_start != std::string::npos) {
        size_t t1_end = input.find('?', t1_start);
        if (t1_end != std::string::npos) {
            std::string t1_data = input.substr(t1_start, t1_end - t1_start + 1);

            // Convert ASCII to simulated bitstream for Track 1 (7 bits per char)
            std::string bits;
            for (char c : t1_data) {
                // Find character in Track 1 table
                const char* ptr = std::find(std::begin(TRACK1_CHARS), std::end(TRACK1_CHARS), c);
                if (ptr != std::end(TRACK1_CHARS)) {
                    int idx = static_cast<int>(ptr - TRACK1_CHARS);
                    // Add odd parity bit
                    int parity = (__builtin_popcount(idx) % 2) == 0 ? 1 : 0;
                    int full = (parity << 6) | idx;
                    for (int b = 0; b < 7; ++b) {
                        bits += ((full >> b) & 1) ? '1' : '0';
                    }
                }
            }

            TrackData td = parsers_[0]->parse(bits);
            td.raw = t1_data; // Use the actual keyboard input
            td.valid = true;
            card.tracks.push_back(td);
        }
    }

    // Track 2 starts with ';'
    size_t t2_start = input.find(';');
    if (t2_start != std::string::npos) {
        size_t t2_end = input.find('?', t2_start);
        if (t2_end != std::string::npos) {
            std::string t2_data = input.substr(t2_start, t2_end - t2_start + 1);

            std::string bits;
            for (char c : t2_data) {
                const char* ptr = std::find(std::begin(TRACK23_CHARS), std::end(TRACK23_CHARS), c);
                if (ptr != std::end(TRACK23_CHARS)) {
                    int idx = static_cast<int>(ptr - TRACK23_CHARS);
                    int parity = (__builtin_popcount(idx) % 2) == 0 ? 1 : 0;
                    int full = (parity << 4) | idx;
                    for (int b = 0; b < 5; ++b) {
                        bits += ((full >> b) & 1) ? '1' : '0';
                    }
                }
            }

            TrackData td = parsers_[1]->parse(bits);
            td.raw = t2_data;
            td.valid = true;
            card.tracks.push_back(td);
        }
    }

    card.card_type = CardAnalyzer::analyze(card);
    card.card_type_name = CardAnalyzer::get_card_name(card.card_type);

    auto t2 = card.get_track(TrackID::Track2);
    if (t2 && !t2->pan.empty()) {
        card.issuing_bank = CardAnalyzer::get_issuing_bank(t2->pan);
    }

    return card;
}

ParsedCard StripeSnoop::parse_raw_bytes(const std::vector<uint8_t>& data) {
    // Convert bytes to bitstream and parse
    std::string bits;
    for (uint8_t b : data) {
        for (int i = 7; i >= 0; --i) {
            bits += ((b >> i) & 1) ? '1' : '0';
        }
    }
    return parse_bitstream(bits);
}

// ============================================================================
// Utilities
// ============================================================================

namespace utils {

std::vector<uint8_t> bits_to_bytes(const std::string& bits) {
    std::vector<uint8_t> bytes;
    for (size_t i = 0; i < bits.length(); i += 8) {
        uint8_t b = 0;
        for (size_t j = 0; j < 8 && (i + j) < bits.length(); ++j) {
            if (bits[i + j] == '1') {
                b |= (1 << (7 - j));
            }
        }
        bytes.push_back(b);
    }
    return bytes;
}

uint8_t calculate_lrc(const std::vector<uint8_t>& data) {
    uint8_t lrc = 0;
    for (uint8_t b : data) {
        lrc ^= b;
    }
    return lrc;
}

bool check_parity(uint8_t value, size_t bits, ParityType type) {
    uint8_t count = __builtin_popcount(value & ((1 << bits) - 1));
    if (type == ParityType::Odd) {
        return (count % 2) == 1;
    }
    return (count % 2) == 0;
}

std::string hexdump(const std::vector<uint8_t>& data) {
    std::stringstream ss;
    for (size_t i = 0; i < data.size(); ++i) {
        if (i > 0 && i % 16 == 0) ss << "\n";
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(data[i]) << " ";
    }
    return ss.str();
}

std::string lookup_bank(uint32_t bin) {
    // Simplified BIN lookup table
    if (bin >= 400000 && bin <= 499999) return "Visa Network";
    if (bin >= 510000 && bin <= 559999) return "MasterCard Network";
    if (bin >= 340000 && bin <= 349999) return "American Express";
    if (bin >= 370000 && bin <= 379999) return "American Express";
    if (bin >= 352800 && bin <= 358999) return "JCB";
    if (bin >= 601100 && bin <= 601199) return "Discover";
    if (bin >= 644000 && bin <= 649999) return "Discover";
    if (bin >= 650000 && bin <= 659999) return "Discover";
    if (bin >= 300000 && bin <= 305999) return "Diners Club";
    if (bin >= 309500 && bin <= 309599) return "Diners Club";
    if (bin >= 360000 && bin <= 369999) return "Diners Club";
    if (bin >= 380000 && bin <= 399999) return "Diners Club";

    // Some specific US banks
    if (bin >= 431300 && bin <= 431399) return "Maryland Bank NA (MBNA)";
    if (bin >= 400000 && bin <= 499999) return "Visa Issuer";
    if (bin >= 510000 && bin <= 559999) return "MasterCard Issuer";

    return "Unknown Bank";
}

} // namespace utils

} // namespace stripesnoop
